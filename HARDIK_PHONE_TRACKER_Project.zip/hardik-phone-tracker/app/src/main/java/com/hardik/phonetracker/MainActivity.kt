package com.hardik.phonetracker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices

class MainActivity : Activity() {
    private val requestCode = 204
    private lateinit var status: TextView
    private lateinit var phone: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(36,36,36,36); setBackgroundColor(0xFF101318.toInt()) }
        fun text(s: String, size: Float) = TextView(this).apply { text=s; textSize=size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,14,0,14) }
        layout.addView(text("HARDIK PHONE TRACKER", 24f))
        layout.addView(text("Share or request location with consent", 15f))
        phone = EditText(this).apply { hint="Phone number (optional)"; setHintTextColor(0xFFAAAAAA.toInt()); setTextColor(-1); inputType=3 }
        layout.addView(phone)
        val request = Button(this).apply { text="Send location request (SMS)" }
        layout.addView(request)
        val share = Button(this).apply { text="Share MY location" }
        layout.addView(share)
        status = text("Location is not shared until you choose to share it.", 14f)
        layout.addView(status)
        request.setOnClickListener {
            val number = phone.text.toString().trim()
            if (number.isBlank()) { phone.error="Enter phone number"; return@setOnClickListener }
            val sms = "Hi, please share your location with me if you are comfortable. You can use Google Maps location sharing: https://support.google.com/maps/answer/7326816"
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", sms))
        }
        share.setOnClickListener { checkPermissionAndShare() }
        setContentView(layout)
    }
    private fun checkPermissionAndShare() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            return
        }
        getMyLocation()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) getMyLocation()
        else status.text="Permission denied. Your location was not accessed."
    }
    private fun getMyLocation() {
        status.text="Getting your location…"
        LocationServices.getFusedLocationProviderClient(this).lastLocation
            .addOnSuccessListener { loc: Location? ->
                if (loc == null) { status.text="No recent location. Turn on GPS and try again."; return@addOnSuccessListener }
                val link="https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
                status.text="Your location link is ready. Choose an app to share it."
                val chooser=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT, "My location: $link") }
                startActivity(Intent.createChooser(chooser, "Share my location"))
            }.addOnFailureListener { status.text="Could not retrieve location: ${it.localizedMessage ?: "unknown error"}" }
    }
}
