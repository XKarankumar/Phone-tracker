# HARDIK PHONE TRACKER (Starter Android Project)

This starter app is consent-based. It cannot locate a person merely by entering their phone number. The number field opens the SMS app with a request asking the recipient to share their location voluntarily. The **Share MY location** button asks for Android location permission, gets this device's last known location, and lets the user choose an app to share the Maps link.


## Build APK
1. Upload this project to a GitHub repository (main branch).
2. In GitHub, open **Actions** and run or wait for **Build Android APK**.
3. Open the successful workflow run, find **Artifacts**, download `HardikPhoneTracker-debug-apk`, unzip it, and install `app-debug.apk` on Android.


## Build locally
Install Android Studio/Android SDK and Gradle, then run:

`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Limitations
- No covert phone-number tracking, carrier-location lookup, or remote tracking backend.
- No real-time background tracking; this is a one-time last-known-location share.
- SMS request is a draft/intent; the user must review and send it.
- Location sharing requires recipient consent and their own location-sharing tools.
